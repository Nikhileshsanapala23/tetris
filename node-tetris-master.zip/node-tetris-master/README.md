# node-tetris

Tetris game with nodejs in terminal. (require node 7)

### Play

move by arrow key

rotate by space

ctl + c or esc to escape


```
node .
```

![alt text](https://github.com/sonnn/node-tetris/blob/master/screen-shoot.png)

